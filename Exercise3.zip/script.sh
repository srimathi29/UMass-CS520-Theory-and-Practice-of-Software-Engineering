#!/bin/sh
# writing script again for autograder- used inline command in answers which also worked.
if ant clean test | grep -q 'FAILED'; then
    exit 1
else
    exit 0
fi
