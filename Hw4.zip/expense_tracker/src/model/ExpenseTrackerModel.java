package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The ExpenseTrackerModel class represents the model component in an MVC pattern for an expense tracker application.
 * It manages the financial transactions and the indices of transactions that match certain filters.
 * This class also implements the Observable part of the Observer design pattern, allowing listeners to register
 * and be notified of changes in the model's state.
 */

public class ExpenseTrackerModel {

  //encapsulation - data integrity
  private List<Transaction> transactions;
  private List<Integer> matchedFilterIndices;
  private List<ExpenseTrackerModelListener> listeners;
  // This is applying the Observer design pattern.                          
  // Specifically, this is the Observable class. 

   /**
     * Constructs a new ExpenseTrackerModel with empty lists for transactions and matched filter indices.
     */
  public ExpenseTrackerModel() {
    transactions = new ArrayList<Transaction>();
    matchedFilterIndices = new ArrayList<Integer>();
    listeners = new ArrayList<ExpenseTrackerModelListener>();
  }

   /**
     * Adds a transaction to the expense tracker.
     * 
     * @param t The Transaction to be added; must not be null.
     * @throws IllegalArgumentException If the provided transaction is null.
     */
  public void addTransaction(Transaction t) {
    // Perform input validation to guarantee that all transactions added are non-null.
    if (t == null) {
      throw new IllegalArgumentException("The new transaction must be non-null.");
    }
    transactions.add(t);
    // The previous filter is no longer valid.
    matchedFilterIndices.clear();
    stateChanged();
  }

   /**
     * Removes a specific transaction from the expense tracker.
     * 
     * @param t The Transaction to be removed; it should already exist in the tracker.
     *          If the transaction is not found, no action is taken.
     */
  public void removeTransaction(Transaction t) {
    transactions.remove(t);
    // The previous filter is no longer valid.
    matchedFilterIndices.clear();
    stateChanged();
  }

  /**
     * Retrieves an unmodifiable list of all transactions in the expense tracker.
     * This method ensures that the internal list of transactions cannot be altered directly.
     * 
     * @return An unmodifiable list of Transaction objects.
     */
  public List<Transaction> getTransactions() {
    //encapsulation - data integrity
    return Collections.unmodifiableList(new ArrayList<>(transactions));
  }

  /**
     * Sets the indices of transactions that match a certain filter.
     * 
     * @param newMatchedFilterIndices A list of indices indicating the transactions that match the filter.
     * @throws IllegalArgumentException If the input list is null or contains invalid indices.
     */
  public void setMatchedFilterIndices(List<Integer> newMatchedFilterIndices) {
      // Perform input validation
      if (newMatchedFilterIndices == null) {
	  throw new IllegalArgumentException("The matched filter indices list must be non-null.");
      }
      for (Integer matchedFilterIndex : newMatchedFilterIndices) {
	  if ((matchedFilterIndex < 0) || (matchedFilterIndex > this.transactions.size() - 1)) {
	      throw new IllegalArgumentException("Each matched filter index must be between 0 (inclusive) and the number of transactions (exclusive).");
	  }
      }
      // For encapsulation, copy in the input list 
      this.matchedFilterIndices.clear();
      this.matchedFilterIndices.addAll(newMatchedFilterIndices);
      stateChanged();
  }

  /**
     * Retrieves a copy of the list of indices for transactions that match the current filter.
     * 
     * @return A list of integers representing the matched filter indices.
     */
  public List<Integer> getMatchedFilterIndices() {
      // For encapsulation, copy out the output list
      List<Integer> copyOfMatchedFilterIndices = new ArrayList<Integer>();
      copyOfMatchedFilterIndices.addAll(this.matchedFilterIndices);
      return copyOfMatchedFilterIndices;
  }

  /**
   * Registers the given ExpenseTrackerModelListener for
   * state change events.
   *
   * @param listener The ExpenseTrackerModelListener to be registered
   * @return If the listener is non-null and not already registered,
   *         returns true. If not, returns false.
   */   
  public boolean register(ExpenseTrackerModelListener listener) {
      // For the Observable class, this is one of the methods.
      //
      if(listener == null ) {
        return false;
      }
      if(!containsListener(listener)) {
        listeners.add(listener);
        return true;
      }
      return false;
  }

  /**
     * Returns the number of listeners currently registered with this ExpenseTrackerModel.
     * 
     * @return The number of registered listeners.
     */
  public int numberOfListeners() {
      // For testing, this is one of the methods.
      //
      return listeners.size();
  }

  /**
     * Checks if a specific listener is registered with this ExpenseTrackerModel.
     * 
     * @param listener The listener to check for.
     * @return true if the listener is registered, false otherwise.
     */
  public boolean containsListener(ExpenseTrackerModelListener listener) {
      // For testing, this is one of the methods.
      //
      
      return listeners.contains(listener);
  }

  /**
     * Notifies all registered listeners of a state change in the ExpenseTrackerModel.
     * This method should be called whenever the internal state of the model changes in a way that observers should be made aware of.
     */
  protected void stateChanged() {
      // For the Observable class, this is one of the methods.
      //
      for (ExpenseTrackerModelListener listener : listeners) {
          listener.update(this);
  }
}
}