package view;

import model.RowGameModel;


public interface RowGameView
{
    public void update(RowGameModel gameModel);
}
