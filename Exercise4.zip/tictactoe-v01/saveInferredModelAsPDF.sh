#!/bin/bash

echo "Converting dot file to PDF...";
dot rowGameApp-arch.dot -Tpdf -o "rowGameApp-arch.pdf"
