package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

public class ExpenseTrackerModel {

  //encapsulation - data integrity
  private List<Transaction> transactions;
  private Stack<Transaction> undoStack = new Stack<>(); 

  private Stack<String> actionHistory = new Stack<>();
  public ExpenseTrackerModel() {
    transactions = new ArrayList<>(); 
  }

  public void addTransaction(Transaction t) {
    // Perform input validation to guarantee that all transactions added are non-null.
    if (t == null) {
      throw new IllegalArgumentException("The new transaction must be non-null.");
    }
    transactions.add(t);
    actionHistory.push("ADD:"+t.getAmount()+":"+t.getCategory());
    undoStack.push(t);
  }

  public void removeTransaction(Transaction t) {
    transactions.remove(t);
    actionHistory.push("REMOVE:"+t.getAmount()+":"+t.getCategory());

  }

  public String getLastAction() {
    return actionHistory.isEmpty() ? null : actionHistory.pop();
  }

  public List<Transaction> getTransactions() {
    //encapsulation - data integrity
    return Collections.unmodifiableList(new ArrayList<>(transactions));
  }

  public void addToStack(Transaction t) {
    undoStack.push(t);
  }

  public boolean canUndo() {
    return !undoStack.isEmpty();
  }
  
  public void undoLastAction() {
    
    // if (!undoStack.isEmpty()) {
    //     Transaction t = undoStack.pop();
    //     addTransaction(t);
    // }
    String lastAction = getLastAction();
    if (lastAction != null) {
        String[] parts = lastAction.split(":");
        String actionType = parts[0];
        double amount = Double.parseDouble(parts[1]);
        String category = parts[2];
        if (!undoStack.isEmpty()) {
        Transaction t = undoStack.pop();
        switch (actionType) {
            case "ADD":
                // Find and remove the transaction with this ID
                transactions.remove(t);
                break;
            case "REMOVE":
                // Find and re-add the transaction with this ID
                addTransaction(t);
                break;
        }
      }
    }
}
}
