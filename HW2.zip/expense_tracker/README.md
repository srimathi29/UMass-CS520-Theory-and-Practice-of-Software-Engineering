# hw1- Manual Review

The homework will be based on this project named "Expense Tracker",where users will be able to add/remove daily transaction. 

## Compile

To compile the code from terminal, use the following command:
```
cd src
javac ExpenseTrackerApp.java
java ExpenseTracker
```

You should be able to view the GUI of the project upon successful compilation. 

## Java Version
This code is compiled with ```openjdk 17.0.7 2023-04-18```. Please update your JDK accordingly if you face any incompatibility issue.


## New Functionalities

### 1. Filtering
The application now enables and supports filtering the transactions added. 
But the capability of filtering is limited to filter either by amount or by category at a given instance. 
The filtered rows/transactions are highlighted in green color along with all the transactions present.

**Using the Category filter:**
1. Choose the category provided in the drop-down.
2. Press the "Apply Filter" button. 
Note: When the category filter drop-down is selected by any value other than "None" the application
only filters on the category selected, ignoring the minAmount and maxAmount values. 

**Using the Amount filter:**
1. Select the category drop-down to show "None"
2. Enter the range of amounts needed to be filtered in minAmount and maxAmount fields
3. Press the "Apply Filter" button. 


For the two filtering options the inputvalidation is applied to allow only valid values in the fields to be filtered or considered. 


