package controller;

import view.ExpenseTrackerView;
import model.TransactionFilter;

import java.util.ArrayList;
import java.util.List;



import model.ExpenseTrackerModel;
import model.Transaction;
public class ExpenseTrackerController {
  
  private ExpenseTrackerModel model;
  private ExpenseTrackerView view;
  private TransactionFilter currentFilter;
  
  public ExpenseTrackerController(ExpenseTrackerModel model, ExpenseTrackerView view) {
    this.model = model;
    this.view = view;
    // Set up view event handlers
  }

  public void setTransactionFilter(TransactionFilter filter) {
    this.currentFilter = filter;
  }

  public void refresh() {

    // Get transactions from model
    List<Transaction> transactions = model.getTransactions();

    // Pass to view
    view.refreshTable(transactions);
  }

  public boolean addTransaction(double amount, String category) {
    if (!InputValidation.isValidAmount(amount)) {
      return false;
    }
    if (!InputValidation.isValidCategory(category)) {
      return false;
    }
    
    Transaction t = new Transaction(amount, category);
    model.addTransaction(t);
    view.getTableModel().addRow(new Object[]{t.getAmount(), t.getCategory(), t.getTimestamp()});
    refresh();
    return true;
  }
  
  // Other controller methods
  public boolean applyFilter() {

    // apply the filter to the original transactions and store them somewhere. 
    List<Transaction>  filteredTransactions = currentFilter.filter(model.getTransactions());
    System.out.println("filtering went well");
    view.refreshTable(filteredTransactions);
    view.HighlightTransactions(filteredTransactions);
    System.out.println("Highlighting went well");
    // refresh();
    // System.out.println("refresh went well");
    return true;
  }

}