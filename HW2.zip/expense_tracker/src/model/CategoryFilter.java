package model;

import controller.InputValidation;
import java.util.ArrayList;
import java.util.List;

public class CategoryFilter implements TransactionFilter {
    private String category;

    public CategoryFilter(String category) {
        this.category = category;
    }

    @Override
    public List<Transaction> filter(List<Transaction> transactions) {
        List<Transaction> filteredTransactions = new ArrayList<>();
        // System.out.println("INSIDE THE MAIN CATEGORY FILTER");
        for (Transaction transaction : transactions) {
            if (InputValidation.isValidCategory(transaction.getCategory())) {
                if (transaction.getCategory().equalsIgnoreCase(category)) {
                    // Highlight matched transaction (change its color to green)
                    transaction.highlight(); // Implement highlighting logic in your Transaction class
                    filteredTransactions.add(transaction);
                }
            }
        }

        return filteredTransactions;
    }


}
