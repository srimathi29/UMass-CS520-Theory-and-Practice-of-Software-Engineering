import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.ExpenseTrackerController;
import model.AmountFilter;
import model.CategoryFilter;
import model.ExpenseTrackerModel;
import view.ExpenseTrackerView;
import model.Transaction;
import model.TransactionFilter;
import controller.InputValidation;

public class ExpenseTrackerApp {

  public static void main(String[] args) {
    
    // Create MVC components
    ExpenseTrackerModel model = new ExpenseTrackerModel();
    ExpenseTrackerView view = new ExpenseTrackerView();
    ExpenseTrackerController controller = new ExpenseTrackerController(model, view);

    // Initialize view
    view.setVisible(true);

    // Handle add transaction button clicks
    view.getAddTransactionBtn().addActionListener(e -> {
      // Get transaction data from view
      double amount = view.getAmountField();
      String category = view.getCategoryField();
      
      // Call controller to add transaction
      boolean added = controller.addTransaction(amount, category);
      
      if (!added) {
        JOptionPane.showMessageDialog(view, "Invalid amount or category entered");
        view.toFront();
      }
    });


    // Handle the filter button clicks 
    view.getApplyFilterBtn().addActionListener( e -> {
      String selectedCategory = (String) view.getCategoryFilterComboBox().getSelectedItem();
            double minAmount = view.getMinAmountField();
            double maxAmount = view.getMaxAmountField();
            // category filter only works when category is not NONE else amount filter will work
            if (!selectedCategory.equals("None")) {
                // Handle category filter
                System.out.println("in category filtering");
                TransactionFilter filter = new CategoryFilter(selectedCategory);
                controller.setTransactionFilter(filter);
                boolean filtered = controller.applyFilter();
                System.out.println("out category filtering");
                if (!filtered) {
                  JOptionPane.showMessageDialog(view, "Invalid filtering options selected");
                  view.toFront();
                }
            } else if (minAmount >= 0 && maxAmount >= minAmount) {
                // Handle amount filter
                System.out.println("in amount filtering");
                TransactionFilter filter = new AmountFilter(minAmount, maxAmount);
                controller.setTransactionFilter(filter);
                boolean filtered = controller.applyFilter();
                System.out.println("out amount filtering");
                if (!filtered) {
                  JOptionPane.showMessageDialog(view, "Invalid filtering options selected");
                  view.toFront();
                }
            } else {
                // No filter selected, show a message or handle as needed
            }
        });
    
  }

}