# test_decisionCoverage.py
import unittest
from isTriangle import Triangle

class test_decisionCoverage(unittest.TestCase):
    def test_invalid_side_length(self):
        actual = Triangle.classify(0, 1, 2)
        self.assertEqual(actual, Triangle.Type.INVALID)

    def test_equilateral_triangle(self):
        actual = Triangle.classify(7, 7, 7)
        self.assertEqual(actual, Triangle.Type.EQUILATERAL)

    def test_isosceles_triangle(self):
        actual = Triangle.classify(5, 5, 8)
        self.assertEqual(actual, Triangle.Type.ISOSCELES)
    
    def test_isosceles_triangle2(self):
        actual = Triangle.classify(8, 5, 5)
        self.assertEqual(actual, Triangle.Type.ISOSCELES)

    def test_isosceles_triangle3(self):
        actual = Triangle.classify(5, 8, 5)
        self.assertEqual(actual, Triangle.Type.ISOSCELES)

    def test_invalid_triangle_neglen(self):
        actual = Triangle.classify(-1, -2, -3)
        self.assertEqual(actual, Triangle.Type.INVALID)
    
    def test_invalid_triangle2(self):
        actual = Triangle.classify(1, 2, 3)
        self.assertEqual(actual, Triangle.Type.INVALID)
    
    def test_valid_triangle(self):
        actual = Triangle.classify(3, 4, 5)
        self.assertEqual(actual, Triangle.Type.SCALENE)

    def test_valid_triangle2(self):
        actual = Triangle.classify(4, 5, 5)
        self.assertEqual(actual, Triangle.Type.SCALENE)
if __name__ == '__main__':
    unittest.main()
