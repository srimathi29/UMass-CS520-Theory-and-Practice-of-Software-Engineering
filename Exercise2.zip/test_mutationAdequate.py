# test_mutationAdequate.py
import unittest
from isTriangle import Triangle

class test_mutationAdequate(unittest.TestCase):
    def testEquilateral(self):
        actual = Triangle.classify(10, 10, 10)
        self.assertEqual(actual, Triangle.Type.EQUILATERAL)

    def testScalene(self):
        actual = Triangle.classify(10, 11, 12)
        self.assertEqual(actual, Triangle.Type.SCALENE)
    
    def testIsosceles1(self):
        actual = Triangle.classify(10, 10, 12)
        self.assertEqual(actual, Triangle.Type.ISOSCELES)
    
    def testIsosceles2(self):
        actual = Triangle.classify(10, 12, 10)
        self.assertEqual(actual, Triangle.Type.ISOSCELES)
    
    def testIsosceles3(self):
        actual = Triangle.classify(12, 10, 10)
        self.assertEqual(actual, Triangle.Type.ISOSCELES)

    def testInvalid(self):
        actual = Triangle.classify(-10, 10, 12)
        self.assertEqual(actual, Triangle.Type.INVALID)

    def testViolateInequality(self):
        actual = Triangle.classify(10, 5, 4)
        self.assertEqual(actual, Triangle.Type.INVALID)
    
    def testViolateInequalityIsos1(self):
        actual = Triangle.classify(10, 10, 25)
        self.assertEqual(actual, Triangle.Type.INVALID)

    def testViolateInequalityIsos2(self):
        actual = Triangle.classify(10, 25, 10)
        self.assertEqual(actual, Triangle.Type.INVALID)
    
    def testViolateInequalityIsos3(self):
        actual = Triangle.classify(25, 10, 10)
        self.assertEqual(actual,  Triangle.Type.INVALID)

    def testInvalidTriangleMutan1(self):
        #line20,21
        actual = Triangle.classify(-1,-10,-20)
        self.assertEqual(actual,Triangle.Type.INVALID)

    def testInvalidTriangleMutant2(self):
        #line 34,35
        actual = Triangle.classify(1,2,3)
        self.assertEqual(actual,Triangle.Type.INVALID)

    def testInvalidTriangleMutant3(self):
        #line 20,21
        actual = Triangle.classify(1,-2,3)
        self.assertEqual(actual,Triangle.Type.INVALID)

    def testInvalidTriangleMutant4(self):
        #line 20,21
        actual = Triangle.classify(10,10,-3)
        self.assertEqual(actual,Triangle.Type.INVALID)

    def testInvalidTriangleMutant5(self):
        #line 20,21
        actual = Triangle.classify(-10,10,-3)
        self.assertEqual(actual,Triangle.Type.INVALID)

    def testInvalidTriangleMutant6(self):
        #line 20,21
        actual = Triangle.classify(10,-10,-3)
        self.assertEqual(actual,Triangle.Type.INVALID)
    
    def testInvalidTriangleMutant7(self):
        #line 20,21
        actual = Triangle.classify(-10,-10,3)
        self.assertEqual(actual,Triangle.Type.INVALID)

    def testInvalidTriangleMutant8(self):
        #line 20,21
        actual = Triangle.classify(0,0,0)
        self.assertEqual(actual,Triangle.Type.INVALID)
        
    def testInvalidTriangleMutant9(self):
        #line 20,21
        actual = Triangle.classify(0,2,3)
        self.assertEqual(actual,Triangle.Type.INVALID)

    def testInvalidTriangleMutant10(self):
        #line 20,21
        actual = Triangle.classify(3,0,3)
        self.assertEqual(actual,Triangle.Type.INVALID)

    def testInvalidTriangleMutant11(self):
        #line 20,21
        actual = Triangle.classify(3,3,0)
        self.assertEqual(actual,Triangle.Type.INVALID)     

    def testInvalidTriangleMutant12(self):
        #line34,35
        actual = Triangle.classify(3,4,8)
        self.assertEqual(actual,Triangle.Type.INVALID) 

    def testInvalidTriangleMutant13(self):
        #line34,35
        actual = Triangle.classify(1,2,1)
        self.assertEqual(actual,Triangle.Type.INVALID)

    def testIsoscelesTriangleMutant1(self):
        #line34,35
        actual = Triangle.classify(3,3,6)
        self.assertEqual(actual,Triangle.Type.INVALID)
    

if __name__ == '__main__':
    unittest.main()
