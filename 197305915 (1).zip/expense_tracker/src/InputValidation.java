import java.util.*;



public class InputValidation {

    public Boolean isValidAmount(double amount) {
        if(amount > 0 && amount <1000 ) {
            return true;
        }
        else return false;
    }

    public Boolean isValidCategory(String category) {
        List<String> arr = new ArrayList<String>(5);
        arr.add("food");
        arr.add("travel");
        arr.add("bills");
        arr.add("entertainment");
        arr.add("other");
        // if(category == "food" || category == "travel" || category == "bills" || category == "entertainment" || category == "other")
        if(arr.contains(category))
            return true;
        else return false;
    }
}