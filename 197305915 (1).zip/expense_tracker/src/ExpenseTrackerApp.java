import javax.swing.table.DefaultTableModel;
import java.util.logging.*;
import javax.swing.JOptionPane;

/**
 * The ExpenseTrackerApp class allows users to add/remove daily transactions.
 */
public class ExpenseTrackerApp {

  public static void main(String[] args) {
    
    // Create MVC components
    DefaultTableModel tableModel = new DefaultTableModel();
    tableModel.addColumn("Serial");
    tableModel.addColumn("Amount");
    tableModel.addColumn("Category");
    tableModel.addColumn("Date");
    

    
    ExpenseTrackerView view = new ExpenseTrackerView(tableModel);

    // Initialize view
    view.setVisible(true);

    // Handle add transaction button clicks
    view.getAddTransactionBtn().addActionListener(e -> {
      
      // Get transaction data from view
      double amount = view.getAmountField(); 
      String category = view.getCategoryField();
      InputValidation validator = new InputValidation();  

      try {
      // Validate the inputs
      if(!validator.isValidAmount(amount)) {
        throw new IllegalArgumentException("Invalid Amount");
      }
      if(!validator.isValidCategory(category)){
        throw new IllegalArgumentException("Invalid Category");
      }
      }
      catch (IllegalArgumentException ex){
          System.err.println("Validation Exception: " + ex.getMessage());
           JOptionPane.showMessageDialog(null, "Invalid argument: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
      }

      if(validator.isValidAmount(amount) && validator.isValidCategory(category)) {
        // Create transaction object
        Transaction t = new Transaction(amount, category);

        // Call controller to add transaction
        view.addTransaction(t);
      }
    });

  }

}